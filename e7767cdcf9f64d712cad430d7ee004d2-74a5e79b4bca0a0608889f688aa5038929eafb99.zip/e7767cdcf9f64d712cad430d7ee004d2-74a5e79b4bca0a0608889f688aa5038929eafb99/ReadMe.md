Objective:To develope an app or mobile solution using atleast one ICICI bank API to make financial services mobile friendly.


Basic Idea:
Across the globe,banking and finance play a vital role in governing the economy of a country.The stock market in India and shares growth affect a large chunk of Indian economy.So we need to make our financial services API's so clear and concise so as to compete the International market and beat their business model in all aspects.We need to make use of Bank API's and modify them so as to make trading in India easy and reliable and it has to be well networked using mobile solutions to provide reliable data and transactions so that we can beat the Singapore and Malaysian Bursa Stock market and give India a different stand among the crowd.All and all make it Internationally accepted commercialized.We can take help form Yahoo and Google for basic integration.

Firstly,we need to create a web-page that allows users to search for stock quotes and financial company news using the Yahoo! Finance Web Services and Yahoo! Company News RSS feed APIs, and the results will be displayed in tabular format.

A user will first open a page, called search_stock.php (or any valid page name), where he/she can enter a company symbol search about their stock quotes and their financial news. The user should enter at least one of the company names. If the user did not enter anything clicked on “Search”, then an alert message should be shown with an appropriate message prompting the user inputting a company symbol.

When the input is valid, clicking on the Search button will send a request to your server for HelloWorldExample.php (or whatever your valid page name is) with the form data (You can use either GET or POST in the form action). This script will grab the data sent to it and send the search information to Yahoo! Finance Web Services and Yahoo! Company News RSS feed. For company stock quote information, the PHP script will construct a web service URL to query the Yahoo! Finance Web service using the company symbol appropriately. The following URL retrieves Google stock financial information through its company symbol.

Each web service URL retrieves an XML response and your PHP script parses the returned XML files and extracts the necessary information to display data in a tabular format below the search form.

The returned XML from Yahoo Finance contains a set of information.We will guide you to extract specific information to fill up the necessary data in the result data. The top part of result table displays data extracted from Yahoo! Finance web service. The headline of top part shows company name and the company symbol and three numbers. Table 1 shows the mapping between the Yahoo! Finance XML File and the result table. The value of Change started either with + or - operator. If the value starts with + you should display the second and the third numbers in the headline in green and should show the UP green arrow.

By use of this methodology we are making financial API's strong and trading in India trust-worthy.

